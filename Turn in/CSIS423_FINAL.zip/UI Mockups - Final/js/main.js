/*
	RAVE JavaScript 
	Filename: main.js
	
	Authors: Group 8
		Nathan Chan, Jeffrey Holst, Cristian Johnson, Joseph Scott
	Date: 12/01/17
*/

function populateVehicleForm(){
	//Populates the Edit Fleet and Report Forms with generic data.
	//All values are made up
	var vid = document.getElementById('evidinput').value;
	if(vid == 151){
	//Setting vehicle info
		document.getElementById('emakeinput').value = 'Chevrolet';
		document.getElementById('emodelinput').value = 'Cruze';
		document.getElementById('eyearinput').value = '2014';
		document.getElementById('evininput').value = '1E33Y';
		document.getElementById('emileageinput').value = '60805';
		document.getElementById('edepartmentinput').value = 'IT';
		document.getElementById('eengineinput').value = '1.4L V4 Turbo';
		document.getElementById('etiresinput').value = 'New';
		document.getElementById('econditioninput').value = 'Used';
	}
	if(vid == 261){
		//Setting vehicle info
		document.getElementById('emakeinput').value = 'Ford';
		document.getElementById('emodelinput').value = 'F-150';
		document.getElementById('eyearinput').value = '2001';
		document.getElementById('evininput').value = '1E5653Y';
		document.getElementById('emileageinput').value = '150342';
		document.getElementById('edepartmentinput').value = 'Maintainance';
		document.getElementById('eengineinput').value = '4.2L V6';
		document.getElementById('etiresinput').value = 'Used';
		document.getElementById('econditioninput').value = 'Used';	
}
	if(vid == 420){
		document.getElementById('emakeinput').value = 'Volkswagen';
		document.getElementById('emodelinput').value = 'Jetta';
		document.getElementById('eyearinput').value = '2002';
		document.getElementById('evininput').value = 'XHD4O96ENM714GHQ8';
		document.getElementById('emileageinput').value = '182765';
		document.getElementById('edepartmentinput').value = 'Maintainance';
		document.getElementById('eengineinput').value = '2.0L V4';
		document.getElementById('etiresinput').value = 'Used';
		document.getElementById('econditioninput').value = 'Used';	
	}
}

function populateVehicleReport(){
	//Populates the Edit Fleet and Report Forms with generic data.
	//All values are made up
	var vid = document.getElementById('evidinput').value;
	if(vid == 151){
		//Populating Report Information
		document.getElementById("avgmileageweek").value = "540";
		document.getElementById("avgmileagemonth").value = "2253";
		document.getElementById("avggascostweek").value = "$45";
		document.getElementById("avggascostmonth").value = "$187.75";
		document.getElementById("avgmaintainancemonth").value = "$24.76";
	}
	if(vid == 261){
		//Populating Report Information
		document.getElementById("avgmileageweek").value = "461";
		document.getElementById("avgmileagemonth").value = "1481";
		document.getElementById("avggascostweek").value = "$96.04";
		document.getElementById("avggascostmonth").value = "$308.54";
		document.getElementById("avgmaintainancemonth").value = "$39.46";
	}
	if(vid == 420){
		//Populating Report Information
		document.getElementById("avgmileageweek").value = "310";
		document.getElementById("avgmileagemonth").value = "1240";
		document.getElementById("avggascostweek").value = "$31.54";
		document.getElementById("avggascostmonth").value = "$140.90";
		document.getElementById("avgmaintainancemonth").value = "$42.46";
	}	
}
function populateMaintainanceInfo(){
	//Populates the Edit Fleet and Report Forms with generic data.
	//All values are made up
	var vid = document.getElementById('evidinput').value;
	if(vid == 151){
		//Populating a table with data
		//Getting and clearing the current table
		var table = document.getElementById('maintainancetable');
		table.innerHTML = "";
		
		//Row 0
		var row = table.insertRow(0);
		var cell1 = row.insertCell(0);
		var cell2 = row.insertCell(1);
		var cell3 = row.insertCell(2);
		cell1.innerHTML = "Date Performed";
		cell2.innerHTML = "Scheduled/Special";
		cell3.innerHTML = "Reason";
		
		//Row 1
		var row = table.insertRow(1);
		var cell1 = row.insertCell(0);
		var cell2 = row.insertCell(1);
		var cell3 = row.insertCell(2);
		cell1.innerHTML = "10-01-17";
		cell2.innerHTML = "Scheduled";
		cell3.innerHTML = "Routine Inspection";
		
		//Row 2
		var row = table.insertRow(2);
		var cell1 = row.insertCell(0);
		var cell2 = row.insertCell(1);
		var cell3 = row.insertCell(2);
		cell1.innerHTML = "10-10-17";
		cell2.innerHTML = "Scheduled";
		cell3.innerHTML = "Oil Change";
		
		//Row 3
		var row = table.insertRow(3);
		var cell1 = row.insertCell(0);
		var cell2 = row.insertCell(1);
		var cell3 = row.insertCell(2);
		cell1.innerHTML = "10-25-17";
		cell2.innerHTML = "Scheduled";
		cell3.innerHTML = "Change to Winter Tires";
		
		//Row 4
		var row = table.insertRow(4);
		var cell1 = row.insertCell(0);
		var cell2 = row.insertCell(1);
		var cell3 = row.insertCell(2);
		cell1.innerHTML = "11-01-17";
		cell2.innerHTML = "Scheduled";
		cell3.innerHTML = "Routine Inspection";
		
		//Row 5
		var row = table.insertRow(5);
		var cell1 = row.insertCell(0);
		var cell2 = row.insertCell(1);
		var cell3 = row.insertCell(2);
		cell1.innerHTML = "11-21-17";
		cell2.innerHTML = "Special";
		cell3.innerHTML = "Water Pump Leaking";
		

	}
	if(vid == 261){
		//Populating a table with data
		//Getting and clearing the current table
		var table = document.getElementById('maintainancetable');
		table.innerHTML = "";
		
		//Row 0
		var row = table.insertRow(0);
		var cell1 = row.insertCell(0);
		var cell2 = row.insertCell(1);
		var cell3 = row.insertCell(2);
		cell1.innerHTML = "Date Performed";
		cell2.innerHTML = "Scheduled/Special";
		cell3.innerHTML = "Reason";
		
		//Row 1
		var row = table.insertRow(1);
		var cell1 = row.insertCell(0);
		var cell2 = row.insertCell(1);
		var cell3 = row.insertCell(2);
		cell1.innerHTML = "10-01-17";
		cell2.innerHTML = "Scheduled";
		cell3.innerHTML = "Routine Inspection";
		
		//Row 2
		var row = table.insertRow(2);
		var cell1 = row.insertCell(0);
		var cell2 = row.insertCell(1);
		var cell3 = row.insertCell(2);
		cell1.innerHTML = "10-17-17";
		cell2.innerHTML = "Scheduled";
		cell3.innerHTML = "Oil Change";
		
		//Row 3
		var row = table.insertRow(3);
		var cell1 = row.insertCell(0);
		var cell2 = row.insertCell(1);
		var cell3 = row.insertCell(2);
		cell1.innerHTML = "10-19-17";
		cell2.innerHTML = "Special";
		cell3.innerHTML = "Front Driver Tire Popped - Changed all to Winter Tires";
		
		//Row 4
		var row = table.insertRow(4);
		var cell1 = row.insertCell(0);
		var cell2 = row.insertCell(1);
		var cell3 = row.insertCell(2);
		cell1.innerHTML = "11-01-17";
		cell2.innerHTML = "Scheduled";
		cell3.innerHTML = "Routine Inspection";
		
	}
	if(vid == 420){
		//Populating a table with data
		//Getting and clearing the current table
		var table = document.getElementById('maintainancetable');
		table.innerHTML = "";
		
		//Row 0
		var row = table.insertRow(0);
		var cell1 = row.insertCell(0);
		var cell2 = row.insertCell(1);
		var cell3 = row.insertCell(2);
		cell1.innerHTML = "Date Performed";
		cell2.innerHTML = "Scheduled/Special";
		cell3.innerHTML = "Reason";
		
		//Row 1
		var row = table.insertRow(1);
		var cell1 = row.insertCell(0);
		var cell2 = row.insertCell(1);
		var cell3 = row.insertCell(2);
		cell1.innerHTML = "10-01-17";
		cell2.innerHTML = "Scheduled";
		cell3.innerHTML = "Routine Inspection";
		
		//Row 2
		var row = table.insertRow(2);
		var cell1 = row.insertCell(0);
		var cell2 = row.insertCell(1);
		var cell3 = row.insertCell(2);
		cell1.innerHTML = "10-15-17";
		cell2.innerHTML = "Scheduled";
		cell3.innerHTML = "Oil Change";
		
		//Row 3
		var row = table.insertRow(3);
		var cell1 = row.insertCell(0);
		var cell2 = row.insertCell(1);
		var cell3 = row.insertCell(2);
		cell1.innerHTML = "10-19-17";
		cell2.innerHTML = "Special";
		cell3.innerHTML = "Split muffler in half, had to be put back together.";
		
		//Row 4
		var row = table.insertRow(4);
		var cell1 = row.insertCell(0);
		var cell2 = row.insertCell(1);
		var cell3 = row.insertCell(2);
		cell1.innerHTML = "11-01-17";
		cell2.innerHTML = "Scheduled";
		cell3.innerHTML = "Routine Inspection";
	}	
}
function populateDepartmentReport(){
	//Populates the Department Report with Generic Information
	//All data is made up
	
	//Getting department id
	var did = document.getElementById("didinput").value
	
	if(did == 1){
		document.getElementById("gascostmonth").value = "$74.28";
		document.getElementById("totalmiles").value = "891.36";
		document.getElementById("avgmilesmonth").value = "891.36";
		document.getElementById("avgmaintaincostmonth").value = "$230.43";
		document.getElementById("partscostmonth").value = "$126.43";
		document.getElementById("avgmaintainancerequests").value = "3";
		document.getElementById("avgemployeecost").value = "$2154.23";
	}
	if(did == 2){
		document.getElementById("gascostmonth").value = "$4685.56";
		document.getElementById("totalmiles").value = "17468";
		document.getElementById("avgmilesmonth").value = "1235";
		document.getElementById("avgmaintaincostmonth").value = "$52.96";
		document.getElementById("partscostmonth").value = "$581.96";
		document.getElementById("avgmaintainancerequests").value = "7";
		document.getElementById("avgemployeecost").value = "$1768.41";
	}
}